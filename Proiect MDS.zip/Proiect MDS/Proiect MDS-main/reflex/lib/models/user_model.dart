class UserModel {
  String email;
  String name;
  String imageUrl;

  UserModel({
    this.email = '',
    this.name = '',
    this.imageUrl = 'https://cdn-icons-png.flaticon.com/512/149/149071.png',
  }) {
    if (name.isEmpty) {
      name = email.split('@')[0];
    }
  }

  Map<String, dynamic> toMap() {
    return {
      'email': email,
      'name': name,
      'imageUrl': imageUrl,
    };
  }

  Future<UserModel> copyWith({required String id}) {
    return Future.value(UserModel(
      email: email,
      name: name,
      imageUrl: imageUrl,
    ));
  }

  static fromMap(map) {
    return UserModel(
      email: map['email'],
      name: map['name'],
      imageUrl: map['imageUrl'],
    );
  }
}
