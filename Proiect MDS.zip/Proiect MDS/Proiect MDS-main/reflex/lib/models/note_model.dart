import 'package:flutter/rendering.dart';
import 'package:reflex/auxiliary/methods.dart';
import 'package:reflex/models/user_model.dart';
import 'package:reflex/auxiliary/hexcolor.dart';

class NoteModel {
  String id;
  String title;
  String content;
  Color color;
  DateTime dateCreated;
  DateTime dateModified;
  UserModel user;

  NoteModel({
    required this.id,
    required this.title,
    required this.content,
    required this.color,
    required this.dateCreated,
    required this.dateModified,
    required this.user,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'title': title,
      'content': content,
      'color': colorToHex(color),
      'dateCreated': dateCreated.toIso8601String(),
      'dateModified': dateModified.toIso8601String(),
      'user': user.toMap(),
    };
  }

  static fromMap(map) {
    return NoteModel(
      id: map['id'],
      title: map['title'],
      content: map['content'],
      color: HexColor(map['color']),
      dateCreated: DateTime.parse(map['dateCreated']),
      dateModified: DateTime.parse(map['dateModified']),
      user: UserModel(
        email: map['user']['email'],
        name: map['user']['name'],
        imageUrl: map['user']['imageUrl'],
      ),
    );
  }

  Future<NoteModel> copyWith({required String id}) {
    return Future.value(NoteModel(
      id: id,
      title: title,
      content: content,
      color: color,
      dateCreated: dateCreated,
      dateModified: dateModified,
      user: user,
    ));
  }
}
