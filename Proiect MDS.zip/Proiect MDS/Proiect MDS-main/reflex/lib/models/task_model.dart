import 'package:flutter/material.dart';
import 'package:reflex/models/user_model.dart';

class TaskModel {
  String id;
  String title;
  String description;
  IconData icon;
  DateTime deadline;
  bool isCompleted = false;
  UserModel user;

  TaskModel({
    required this.id,
    required this.title,
    required this.description,
    required this.icon,
    required this.deadline,
    this.isCompleted = false,
    required this.user,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'title': title,
      'description': description,
      'icon': icon.codePoint,
      'deadline': deadline.toIso8601String(),
      'isCompleted': isCompleted,
      'user': user.toMap(),
    };
  }

  static fromMap(map) {
    return TaskModel(
      id: map['id'],
      title: map['title'],
      description: map['description'],
      icon: IconData(map['icon'], fontFamily: 'MaterialIcons'),
      deadline: DateTime.parse(map['deadline']),
      isCompleted: map['isCompleted'] ?? false,
      user: UserModel(
        email: map['user']['email'],
        name: map['user']['name'],
        imageUrl: map['user']['imageUrl'],
      ),
    );
  }

  Future<TaskModel> copyWith({required String id}) {
    return Future.value(TaskModel(
      id: id,
      title: title,
      description: description,
      icon: icon,
      deadline: deadline,
      isCompleted: isCompleted,
      user: user,
    ));
  }
}
