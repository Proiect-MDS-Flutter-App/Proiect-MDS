import 'package:flutter/material.dart';
import 'package:reflex/main.dart';

class BrightnessSettingPage extends StatefulWidget {
  final Brightness theme;

  BrightnessSettingPage({required this.theme});

  @override
  _BrightnessSettingPageState createState() => _BrightnessSettingPageState();
}

class _BrightnessSettingPageState extends State<BrightnessSettingPage> {
  Brightness _brightness = Brightness.light;

  void _updateBrightness(Brightness? brightness) {
    setState(() {
      _brightness = brightness ?? _brightness;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Theme(
      data: _brightness == Brightness.light
          ? ThemeData.light()
          : ThemeData.dark(),
      child: Scaffold(
        appBar: AppBar(
          centerTitle: true,
          title: const Text('Brightness Setting'),
          backgroundColor: Colors.deepPurple,
        ),
        body: Column(
          children: <Widget>[
            ListTile(
              title: const Text('Light'),
              leading: Radio(
                value: Brightness.light,
                groupValue: _brightness,
                onChanged: _updateBrightness,
              ),
            ),
            ListTile(
              title: const Text('Dark'),
              leading: Radio(
                value: Brightness.dark,
                groupValue: _brightness,
                onChanged: _updateBrightness,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
