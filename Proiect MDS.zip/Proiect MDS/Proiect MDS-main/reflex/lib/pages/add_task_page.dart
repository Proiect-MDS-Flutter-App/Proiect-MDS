import 'package:flutter/material.dart';
import 'package:reflex/models/task_model.dart';
import 'package:reflex/models/user_model.dart';
import 'package:reflex/pages/tasks_page.dart';
import 'package:reflex/services/users_service.dart';

class AddTaskPage extends StatefulWidget {
  final List<TaskModel> existingTasks;
  final TaskModel task;
  final ValueChanged<TaskModel> onSave;
  final ValueChanged<TaskModel> onDelete;

  const AddTaskPage({
    required this.existingTasks,
    required this.task,
    required this.onSave,
    required this.onDelete,
  });

  @override
  _AddTaskPageState createState() => _AddTaskPageState();
}

class _AddTaskPageState extends State<AddTaskPage> {
  final _taskTitleController = TextEditingController();
  final _taskDescriptionController = TextEditingController();
  final _taskDeadlineController = TextEditingController();
  final List<IconData> icons = [
    Icons.alarm,
    Icons.phone,
    Icons.work,
    Icons.school,
    Icons.shopping_cart,
  ];

  IconData? _taskIcon = Icons.check_box_outline_blank;
  DateTime _deadline = DateTime.now();
  DateTime compare = DateTime.now();

  final _userService = UserService();
  late UserModel _user;

  @override
  void initState() {
    super.initState();
    _userService.getCurrentUser().then((user) {
      setState(() {
        _user = user;
      });
    });
    if (widget.task != null) {
      _taskTitleController.text = widget.task.title;
      _taskDescriptionController.text = widget.task.description;
      _taskIcon = icons[0];
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text('Add Task'),
        actions: [
          IconButton(
            icon: Icon(Icons.save),
            onPressed: _saveTask,
          ),
          if (widget.task != null)
            IconButton(
              icon: Icon(Icons.delete),
              onPressed: _deleteTask,
            ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            ElevatedButton(
              child:
                  Text(_deadline == null ? 'Set Deadline' : 'Change Deadline'),
              onPressed: () async {
                final selectedDate = await showDatePicker(
                  context: context,
                  initialDate: _deadline ?? DateTime.now(),
                  firstDate: DateTime.now(),
                  lastDate: DateTime(2050),
                );
                if (selectedDate == null) {
                  return;
                }

                final selectedTime = await showTimePicker(
                  context: context,
                  initialTime:
                      TimeOfDay.fromDateTime(_deadline ?? DateTime.now()),
                );
                if (selectedTime == null) {
                  return;
                }

                setState(() {
                  _deadline = DateTime(
                    selectedDate.year,
                    selectedDate.month,
                    selectedDate.day,
                    selectedTime.hour,
                    selectedTime.minute,
                  );
                });
              },
            ),
            SizedBox(height: 16),
            TextField(
              controller: _taskTitleController,
              decoration: InputDecoration(
                labelText: 'Title',
              ),
            ),
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  border: Border.all(
                    color: Colors.black,
                    width: 1,
                  ),
                ),
                child: Padding(
                  padding: const EdgeInsets.only(top: 8, left: 8),
                  child: TextField(
                    maxLines: null,
                    expands: true,
                    controller: _taskDescriptionController,
                    decoration: const InputDecoration(),
                    style: const TextStyle(color: Colors.black),
                  ),
                ),
              ),
            ),
            SizedBox(height: 16),
            DropdownButton(
              items: [
                DropdownMenuItem(
                  child: Icon(Icons.alarm),
                  value: Icons.alarm,
                ),
                DropdownMenuItem(
                  child: Icon(Icons.phone),
                  value: Icons.phone,
                ),
                DropdownMenuItem(
                  child: Icon(Icons.work),
                  value: Icons.work,
                ),
                DropdownMenuItem(
                  child: Icon(Icons.school),
                  value: Icons.school,
                ),
                DropdownMenuItem(
                  child: Icon(Icons.shopping_cart),
                  value: Icons.shopping_cart,
                ),
              ],
              value: _taskIcon,
              onChanged: (value) => setState(() => _taskIcon = value),
            ),
          ],
        ),
      ),
    );
  }

  void _saveTask() {
    {
      if (_taskTitleController.text.isEmpty ||
          _taskDescriptionController.text.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Title and Content can't be empty")),
        );
        return;
      }

      if (_deadline == compare) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Please choose a deadline")),
        );
        return;
      }

      // Check if the task title already exists in the existing task list
      bool taskExists = false;
      for (TaskModel task in widget.existingTasks) {
        if (task.title == _taskTitleController.text &&
            task.deadline.toString() == _taskDeadlineController.text &&
            task.description == _taskDescriptionController) {
          taskExists = true;
          break;
        }
      }

      if (taskExists) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("This task already exists")),
        );
        return;
      }

// Then pass _deadline to the function that requires a DateTime

      final task = TaskModel(
        id: widget.task.id,
        title: _taskTitleController.text,
        description: _taskDescriptionController.text,
        icon: _taskIcon ?? icons[0],
        deadline: _deadline,
        user: _user,
        isCompleted: widget.task.isCompleted,
      );
      widget.onSave(task);
      Navigator.pop(context);
    }
  }

  void _deleteTask() {
    widget.onDelete(widget.task);
    Navigator.pop(context);
  }
}
