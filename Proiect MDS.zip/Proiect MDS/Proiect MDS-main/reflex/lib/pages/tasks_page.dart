import 'package:flutter/material.dart';
import 'package:reflex/models/task_model.dart';
import 'package:reflex/models/user_model.dart';
import 'package:reflex/pages/add_task_page.dart';
import 'package:reflex/services/users_service.dart';
import 'package:reflex/services/tasks_service.dart';

class TasksPage extends StatefulWidget {
  @override
  _TasksPageState createState() => _TasksPageState();
}

class _TasksPageState extends State<TasksPage> {
  final UserService _userService = UserService();
  final TaskService _tasksService = TaskService();
  late List<TaskModel> _tasks = [];
  late UserModel _user;
  final List<IconData> icons = [
    Icons.pets,
    Icons.phone,
    Icons.work,
    Icons.school,
    Icons.shopping_basket,
    Icons.shopping_cart,
  ];

  void _fetchData() async {
    final user = await _userService.getCurrentUser();
    setState(() {
      _user = user;
      _tasksService.getTasksByUser(_user.email).then((tasks) {
        setState(() {
          _tasks = tasks;
        });
      });
    });
  }

  @override
  void initState() {
    _fetchData();
    super.initState();
  }

  @override
  void didUpdateWidget(TasksPage oldWidget) {
    _fetchData();
    super.didUpdateWidget(oldWidget);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text('Tasks'),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _addTask,
        child: Icon(Icons.add),
      ),
      body: ReorderableListView(
        children: _tasks
            .map(
              (task) => _buildTask(task),
            )
            .toList(),
        onReorder: (oldIndex, newIndex) {
          setState(() {
            if (newIndex > oldIndex) {
              newIndex -= 1;
            }
            final TaskModel task = _tasks.removeAt(oldIndex);
            _tasks.insert(newIndex, task);
          });
        },
      ),
    );
  }

  Widget _buildTask(TaskModel task) {
    return Card(
      key: Key(task.title + task.deadline.toString() + task.description),
      child: Container(
        color: task.isCompleted ? Colors.greenAccent.withOpacity(0.3) : null,
        child: ListTile(
          leading: Icon(task.icon),
          title: task.isCompleted
              ? Text(
                  task.title,
                  style: TextStyle(
                    decoration: TextDecoration.lineThrough,
                  ),
                )
              : Text(task.title),
          subtitle: Text(task.deadline.toString()),
          trailing: SizedBox(
            width: 60,
            child: Checkbox(
              value: task.isCompleted,
              onChanged: (value) => _updateTaskCompletion(task, value ?? false),
            ),
          ),
          onTap: () => _editTask(task),
        ),
      ),
    );
  }

  void _updateTaskCompletion(TaskModel task, bool value) {
    setState(() {
      task.isCompleted = value;
      _tasksService.updateTask(task);
    });
  }

  void _addTask() {
    final newTask = TaskModel(
      id: '',
      title: '',
      deadline: DateTime.now(),
      description: '',
      icon: Icons.question_answer,
      user: _user,
    );
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => AddTaskPage(
          existingTasks: _tasks,
          task: newTask,
          onSave: (task) => setState(() {
            _tasks.add(task);
            _tasksService.addTask(task);
          }),
          onDelete: (task) => setState(() {
            _tasks.remove(task);
            _tasksService.deleteTask(task.id);
          }),
        ),
      ),
    );
  }

  void _editTask(TaskModel task) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => AddTaskPage(
          existingTasks: _tasks,
          task: task,
          onSave: (newTask) => setState(() {
            final index = _tasks.indexWhere((t) => t.title == task.title);
            _tasks[index] = newTask;
            _tasksService.updateTask(newTask);
          }),
          onDelete: (task) => setState(() {
            _tasks.remove(task);
            _tasksService.deleteTask(task.id);
          }),
        ),
      ),
    );
  }
}
