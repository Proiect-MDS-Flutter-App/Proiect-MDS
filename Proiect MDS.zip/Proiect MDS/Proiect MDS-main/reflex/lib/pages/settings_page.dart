import 'package:flutter/material.dart';
import 'package:reflex/pages/brightness_setting_page.dart';

class SettingsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Settings"),
      ),
      body: ListView(
        children: <Widget>[
          ListTile(
            leading: Icon(Icons.brightness_medium),
            title: Text("Theme"),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => BrightnessSettingPage(theme: Brightness.light,)),
              );
            },
          ),
          ListTile(
            leading: Icon(Icons.notifications),
            title: Text("Notifications"),
            onTap: () {
              // navigate to notifications setting page
            },
          ),
          ListTile(
            leading: Icon(Icons.security),
            title: Text("Security"),
            onTap: () {
              // navigate to security setting page
            },
          ),
        ],
      ),
    );
  }
}
