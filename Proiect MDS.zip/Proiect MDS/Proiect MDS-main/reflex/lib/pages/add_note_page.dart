import 'package:flutter/material.dart';
import 'package:reflex/models/note_model.dart';
import 'package:reflex/models/user_model.dart';
import 'package:reflex/services/users_service.dart';
import 'package:reflex/pages/notes_page.dart';

class AddNotePage extends StatefulWidget {
  final NoteModel note;
  final Function(NoteModel) onSave;
  final Function(NoteModel) onDelete;

  const AddNotePage({
    super.key,
    required this.onSave,
    required this.note,
    required this.onDelete,
  });

  @override
  _AddNotePageState createState() => _AddNotePageState();
}

class _AddNotePageState extends State<AddNotePage> {
  final _titleController = TextEditingController();
  final _contentController = TextEditingController();
  final _userService = UserService();
  final _addedAt = TextEditingController();
  late UserModel _user;
  Color _color = Colors.deepPurple;

  @override
  void initState() {
    _titleController.text = widget.note.title;
    _contentController.text = widget.note.content;
    _color = widget.note.color;
    _userService.getCurrentUser().then((value) {
      setState(() {
        _user = value;
      });
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text('Add Note'),
        actions: [
          IconButton(
            icon: Icon(Icons.save),
            onPressed: _saveNote,
          ),
          if (widget.note != null)
            IconButton(
              icon: Icon(Icons.delete),
              onPressed: _deleteNote,
            ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            TextField(
              controller: _titleController,
              decoration: const InputDecoration(labelText: 'Title'),
              style: TextStyle(color: _color),
            ),
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  color: _color,
                  border: Border.all(
                    color: Colors.black,
                    width: 1,
                  ),
                ),
                child: Padding(
                  padding: const EdgeInsets.only(top: 8, left: 8),
                  child: TextField(
                    maxLines: null,
                    expands: true,
                    controller: _contentController,
                    decoration: const InputDecoration(),
                    style: const TextStyle(color: Colors.white),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 8),
            Column(
              children: <Widget>[
                const Text("Note color"),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  children: <Widget>[
                    _buildColorOption(Colors.deepPurple),
                    _buildColorOption(Colors.blue),
                    _buildColorOption(Colors.green),
                    _buildColorOption(Colors.orange),
                    _buildColorOption(Colors.red),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }

  Widget _buildColorOption(Color color) {
    return GestureDetector(
      onTap: () => setState(() => _color = color),
      child: Container(
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: color,
        ),
        width: 48,
        height: 48,
        child: _color == color
            ? const Icon(
                Icons.check,
                color: Colors.white,
              )
            : null,
      ),
    );
  }

  void _saveNote() {
    if (_titleController.text.isEmpty || _contentController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Title and Content can't be empty")),
      );
      return;
    }
    final note = NoteModel(
      id: widget.note.id,
      title: _titleController.text,
      content: _contentController.text,
      color: _color,
      dateCreated: widget.note.dateCreated,
      dateModified: DateTime.now(),
      user: _user,
    );
    widget.onSave(note);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Note has been saved")),
    );
    Navigator.pop(context);
  }

  void _deleteNote() {
    if (widget.note == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text("You can't delete a note that doesn't exist")),
      );
      return;
    }
    widget.onDelete(widget.note);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Note has been deleted")),
    );
    Navigator.pop(context);
  }
}
