import 'package:flutter/material.dart';
import 'package:reflex/models/user_model.dart';
import 'package:reflex/pages/add_note_page.dart';
import 'package:reflex/models/note_model.dart';
import 'package:reflex/services/notes_service.dart';
import 'package:reflex/services/users_service.dart';
import 'package:reflex/auxiliary/methods.dart';

class NotesPage extends StatefulWidget {
  @override
  _NotesPageState createState() => _NotesPageState();
}

class _NotesPageState extends State<NotesPage> {
  final UserService _userService = UserService();
  final NotesService _notesService = NotesService();
  late List<NoteModel> _notes = [];
  late UserModel _user;
  String _selectedColor = ""; // Initial value for the dropdown
  List<String> _colors = [
    "All",
    "Red",
    "Green",
    "Blue",
    "Orange",
    "Purple"
  ]; // List of colors you want to display

  void _fetchData() {
    _userService.getCurrentUser().then((value) {
      setState(() {
        _user = value;
        _notesService
            .getNotesByUser(_user.email)
            .then((value) => setState(() => _notes.addAll(value)));
      });
    });
  }

  @override
  void initState() {
    _fetchData();
    super.initState();
  }

  @override
  void didUpdateWidget(covariant NotesPage oldWidget) {
    _fetchData();
    super.didUpdateWidget(oldWidget);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text('Notes'),
        // Add the dropdown button in the AppBar
        actions: <Widget>[
          PopupMenuButton<String>(
            onSelected: (color) => setState(() => _selectedColor = color),
            itemBuilder: (context) => <PopupMenuItem<String>>[
              PopupMenuItem(
                child: Text("All Colors"),
                value: "",
              ),
              PopupMenuItem(
                child: Container(
                  width: 15,
                  height: 15,
                  decoration: BoxDecoration(
                    color: Colors.red,
                    shape: BoxShape.rectangle,
                  ),
                ),
                value: colorToHex(Colors.red),
              ),
              PopupMenuItem(
                child: Container(
                  width: 15,
                  height: 15,
                  decoration: BoxDecoration(
                    color: Colors.orange,
                    shape: BoxShape.rectangle,
                  ),
                ),
                value: colorToHex(Colors.orange),
              ),
              PopupMenuItem(
                child: Container(
                  width: 15,
                  height: 15,
                  decoration: BoxDecoration(
                    color: Colors.green,
                    shape: BoxShape.rectangle,
                  ),
                ),
                value: colorToHex(Colors.green),
              ),
              PopupMenuItem(
                child: Container(
                  width: 15,
                  height: 15,
                  decoration: BoxDecoration(
                    color: Colors.deepPurple,
                    shape: BoxShape.rectangle,
                  ),
                ),
                value: colorToHex(Colors.deepPurple),
              ),
              PopupMenuItem(
                child: Container(
                  width: 15,
                  height: 15,
                  decoration: BoxDecoration(
                    color: Colors.blue,
                    shape: BoxShape.rectangle,
                  ),
                ),
                value: colorToHex(Colors.blue),
              ),
            ],
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _addNote,
        child: Icon(Icons.add),
      ),
      body: ListView.builder(
        itemCount: _notes.length,
        itemBuilder: (context, index) => _selectedColor.isEmpty ||
                colorToHex(_notes[index].color) == _selectedColor
            ? _buildNote(_notes[index])
            : Container(),
      ),
    );
  }

  Widget _buildNote(NoteModel note) {
    return Card(
      color: note.color,
      child: ListTile(
        title: Text(note.title),
        textColor: Colors.white,
        subtitle: Text("Created at: " +
            note.dateCreated.toString() +
            " Last modified: " +
            note.dateModified.toString()),
        onTap: () => _editNote(note),
      ),
    );
  }

  void _addNote() {
    final newNote = NoteModel(
        id: '',
        title: '',
        content: '',
        color: Colors.deepPurple,
        dateCreated: DateTime.now(),
        dateModified: DateTime.now(),
        user: _user);
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => AddNotePage(
          note: newNote,
          onSave: (note) => setState(() {
            _notes.add(note);
            _notesService.addNote(note);
          }),
          onDelete: (note) => setState(() {
            _notes.remove(note);
            _notesService.deleteNote(note.id);
          }),
        ),
      ),
    );
  }

  void _editNote(NoteModel note) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => AddNotePage(
          note: note,
          onSave: (newNote) => setState(() {
            final index = _notes.indexWhere((n) => n.title == note.title);
            _notes[index] = newNote;
            _notesService.updateNote(newNote);
          }),
          onDelete: (note) => setState(() {
            _notes.remove(note);
            _notesService.deleteNote(note.id);
          }),
        ),
      ),
    );
  }
}
