import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:reflex/pages/notes_page.dart';
import 'package:reflex/pages/account_page.dart';
import 'package:reflex/pages/calendar_page.dart';
import 'package:reflex/pages/tasks_page.dart';
import 'package:reflex/pages/focus_page.dart';
// import 'package:reflex/pages/achievements_page.dart';
import 'package:reflex/pages/settings_page.dart';
import 'package:reflex/pages/login_register_page.dart';
import 'package:reflex/widgets/plan-card.dart';
class AchievmentsPage extends StatefulWidget {
  const AchievmentsPage({ Key? key }) : super(key: key);

  @override
  _AchievementPageState createState() => _AchievementPageState();
}
//appBar: AppBar(title: Text("Achievements"),),
class _AchievementPageState extends State<AchievmentsPage> {
  double screenHeight = 0;
  double screenWidth = 0;

  bool startAnimation = false;

  List<String> texts = [
    "Discover Focus Timer",
    "Focus for over 30 minutes",
    "Focus for over 100 minutes ",
    "Acomplish 5 tasks",
    "Acomplish 20 tasks",
    "Acomplish 100 tasks",
  ];

  List<IconData> icons = [
    Icons.lock_clock,
    Icons.lock_clock,
    Icons.lock_clock,
    Icons.assignment,
    Icons.assignment,
    Icons.assignment,

  ];

  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      setState(() {
        startAnimation = true;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    screenHeight = MediaQuery.of(context).size.height;
    screenWidth = MediaQuery.of(context).size.width;

    return Scaffold(
      appBar:AppBar(title: Text("Achievements"),),
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: EdgeInsets.symmetric(
            horizontal: screenWidth / 20,
          ),
          child: Column(
            children: [
              const SizedBox(height: 30,),
              GestureDetector(
                onTap: () {
                  // Future.delayed(const Duration(milliseconds: 500), () {
                  //   setState(() {
                  //     startAnimation = true;
                  //   });
                  // });
                },
                child: const Text(
                  "SHOW LIST",
                  style: TextStyle(
                    fontSize: 30,
                    fontWeight: FontWeight.w600,
                    color: Colors.white,
                  ),
                ),
              ),
              const SizedBox(height: 30,),
              ListView.builder(

                primary: false,
                shrinkWrap: true,
                itemCount: texts.length,
                itemBuilder: (context, index) {
                  return item(index);
                },
              ),
              const SizedBox(height: 50,),
            ],
          ),
        ),
      ),
    );
  }

  Widget item(int index) {
    return AnimatedContainer(
      height: 55,
      width: screenWidth,
      curve: Curves.easeInOut,
      duration: Duration(milliseconds: 300 + (index * 200)),
      transform: Matrix4.translationValues(startAnimation ? 0 : screenWidth, 0, 0),
      margin: const EdgeInsets.only(
        bottom: 12,
      ),
      padding: EdgeInsets.symmetric(
        horizontal: screenWidth / 20,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            "${index + 1}. ${texts[index]}",
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w500,
            ),
          ),
          Icon(
            icons[index],
          ),
        ],
      ),
    );
  }

}