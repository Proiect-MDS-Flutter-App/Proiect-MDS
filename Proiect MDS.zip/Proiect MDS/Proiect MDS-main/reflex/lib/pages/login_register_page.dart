import 'package:flutter/material.dart';
import 'package:reflex/main.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:reflex/models/user_model.dart';
import 'package:reflex/services/auth_service.dart';
import 'package:reflex/services/users_service.dart';
import 'package:flutter/scheduler.dart';

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final AuthService _auth = AuthService();
  final UserService _user = UserService();
  final _formKey = GlobalKey<FormState>();
  String _email = '';
  String _password = '';
  bool isEmailVerified = false;

  // TODO: In late stage development, we will need to verify email

  // void _checkEmailVerification() async {
  //   User? user = await _auth.getCurrentUser();
  //   isEmailVerified = await user!.emailVerified;
  //   if (!isEmailVerified) {
  //     _showVerifyEmailDialog();
  //   }
  // }

  // void _showVerifyEmailDialog() {
  //   showDialog(
  //     context: context,
  //     builder: (BuildContext context) {
  //       return AlertDialog(
  //         title: const Text("Verify your account"),
  //         content: const Text(
  //             "Link to verify account has been sent to your email. Please verify."),
  //         actions: <Widget>[
  //           TextButton(
  //             child: const Text("Dismiss"),
  //             onPressed: () {
  //               Navigator.of(context).pop();
  //             },
  //           ),
  //         ],
  //       );
  //     },
  //   );
  // }

  @override
  void initState() {
    super.initState();
    _auth.authStateChanges.listen((User? user) {
      if (user == null) {
        print('User is currently signed out!');
      } else {
        print('User is signed in!');
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Login'),
      ),
      body: Form(
        key: _formKey,
        child: Column(
          children: [
            TextFormField(
              decoration: const InputDecoration(labelText: 'Email'),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter some text';
                }
                return null;
              },
              onChanged: (value) {
                setState(() {
                  _email = value;
                });
              },
            ),
            TextFormField(
              decoration: const InputDecoration(labelText: 'Password'),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter some text';
                }
                return null;
              },
              obscureText: true,
              onChanged: (value) {
                setState(() {
                  _password = value;
                });
              },
            ),
            ElevatedButton(
              onPressed: () async {
                if (_formKey.currentState!.validate()) {
                  try {
                    await _auth.signIn(_email, _password);
                    // _checkEmailVerification();
                    SchedulerBinding.instance.addPostFrameCallback((_) {
                      Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(builder: (context) => MyApp()),
                      );
                    });
                  } catch (e) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(e.toString()),
                      ),
                    );
                  }
                }
              },
              child: const Text('Login'),
            ),
            ElevatedButton(
              onPressed: () async {
                if (_formKey.currentState!.validate()) {
                  try {
                    await _auth.signUp(_email, _password);
                    await _user.addUser(UserModel(
                      email: _email,
                    ));

                    // _checkEmailVerification();
                    SchedulerBinding.instance.addPostFrameCallback((_) {
                      Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(builder: (context) => MyApp()),
                      );
                    });
                  } catch (e) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(e.toString()),
                      ),
                    );
                  }
                }
              },
              child: const Text('Register'),
            ),

            // Forgot password button
            TextButton(
              onPressed: () async {
                if (_formKey.currentState!.validate()) {
                  await _auth.resetPassword(_email);
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text(
                          'Password reset email has been sent to your email.'),
                    ),
                  );
                }
              },
              child: const Text('Forgot Password?'),
            ),
          ],
        ),
      ),
    );
  }
}
