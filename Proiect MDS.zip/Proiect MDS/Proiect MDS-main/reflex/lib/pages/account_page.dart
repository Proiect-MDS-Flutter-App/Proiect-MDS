import 'dart:io';

import 'package:flutter/material.dart';
import 'package:reflex/models/user_model.dart';
import 'package:reflex/services/image_service.dart';
import 'package:image_picker/image_picker.dart';
import 'package:reflex/services/users_service.dart';

class AccountPage extends StatefulWidget {
  @override
  _AccountPageState createState() => _AccountPageState();
}

class _AccountPageState extends State<AccountPage> {
  final UserService _userService = UserService();
  UserModel? _user;

  TextEditingController _nameController = TextEditingController();
  String imageUrl = '';

  void _fetchData() {
    _userService.getCurrentUser().then((value) {
      setState(() {
        _user = value;
        _nameController.text = _user!.name;
        imageUrl = _user!.imageUrl;
      });
    });
  }

  @override
  void initState() {
    _user = null;
    _fetchData();
    super.initState();
  }

  @override
  void didUpdateWidget(covariant AccountPage oldWidget) {
    _fetchData();
    super.didUpdateWidget(oldWidget);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Account'),
      ),
      body: _user == null
          ? const Center(
              child: CircularProgressIndicator(),
            )
          : Column(
              children: [
                const SizedBox(height: 20),
                Center(
                  child: Stack(
                    children: [
                      CircleAvatar(
                        radius: 50,
                        backgroundImage: NetworkImage(imageUrl),
                      ),
                      Positioned(
                        bottom: 0,
                        right: 0,
                        child: InkWell(
                          onTap: () async {
                            final picker = ImagePicker();
                            final pickedFile = await picker.pickImage(
                              source: ImageSource.gallery,
                            );
                            if (pickedFile != null) {
                              final url = await ImageService.uploadImage(
                                File(pickedFile.path),
                              );
                              setState(() {
                                imageUrl = url;
                              });
                            }
                          },
                          child: const Icon(
                            Icons.camera_alt,
                            color: Colors.teal,
                            size: 28,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: TextField(
                    controller: _nameController,
                    decoration: const InputDecoration(
                      labelText: 'Name',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () async {
                    await _userService.updateUser(
                      UserModel(
                        name: _nameController.text,
                        email: _user!.email,
                        imageUrl: imageUrl,
                      ),
                      _user!.email,
                    );
                    _fetchData();

                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('User updated'),
                      ),
                    );
                  },
                  child: const Text('Save'),
                ),
              ],
            ),
    );
  }
}
