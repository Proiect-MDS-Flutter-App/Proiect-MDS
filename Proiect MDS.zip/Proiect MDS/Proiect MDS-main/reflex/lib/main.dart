import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:reflex/pages/achievements.page.dart';
import 'package:reflex/pages/notes_page.dart';
import 'package:reflex/pages/account_page.dart';
import 'package:reflex/pages/calendar_page.dart';
import 'package:reflex/pages/tasks_page.dart';
import 'package:reflex/pages/focus_page.dart';
// import 'package:reflex/pages/achievements_page.dart';
import 'package:reflex/pages/settings_page.dart';
import 'package:reflex/pages/login_register_page.dart';
import 'package:reflex/widgets/plan-card.dart';

import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';
import 'dart:math';
import 'package:reflex/models/user_model.dart';
import 'package:reflex/services/users_service.dart';
import 'package:reflex/pages/brightness_setting_page.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  MyApp({super.key});
  final Future<FirebaseApp> _firebaseApp = Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    Brightness _brightness = Brightness.light;

    return MaterialApp(
      title: 'Reflex',
      theme: ThemeData(
        primarySwatch: Colors.deepPurple,
        visualDensity: VisualDensity.adaptivePlatformDensity,
        // Adding dark theme
        // brightness: Brightness.dark,
      ),
      home: FutureBuilder(
        future: _firebaseApp,
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            print('You have an error! ${snapshot.error.toString()}');
            return const Text('Something went wrong');
          } else if (snapshot.hasData) {
            return StreamBuilder(
              stream: FirebaseAuth.instance.authStateChanges(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.active) {
                  User? user = snapshot.data;
                  if (user == null) {
                    return LoginPage();
                  }
                  return const MyHomePage(title: 'Reflex');
                  // return LoginPage();
                } else {
                  return const Center(
                    child: CircularProgressIndicator(),
                  );
                }
              },
            );
          } else {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }
        },
      ),

      // This removes the debug banner from the top right corner of the app
      debugShowCheckedModeBanner: false,
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  final TextEditingController searchController = TextEditingController();
  final UserService userService = UserService();
  UserModel? user;
  StreamSubscription<UserModel>? userSubscription;

  String generateGreeting(String name) {
    List<String> greetings = [
      "Welcome back, $name! Get organized and crush your to-do list.",
      "Hello, $name! Plan your day, set your goals, and achieve success.",
      "Good to see you, $name! Let's make today productive and efficient.",
      "Hi there, $name! Stay on track and keep your schedule in check.",
      "Hello, $name! Make the most of your day with smart planning.",
      "Greetings, $name! Take control of your time and tasks.",
      "Hey there, $name! Keep focused, stay motivated, and succeed.",
      "Salutations, $name! Get organized and get things done.",
      "Hello, $name! Let's make every day a productive one.",
      "Hello, $name! Get ahead with smart planning and goal setting.",
    ];

    var random = new Random();
    int index = random.nextInt(greetings.length);

    return greetings[index];
  }

  @override
  void initState() {
    searchController.addListener(() => TextEditingController());
    userService.getCurrentUser().then((value) {
      setState(() {
        user = value;
        userSubscription = userService.streamUser(user!.email).listen((event) {
          setState(() {
            user = event;
          });
        });
      });
    });
    super.initState();
  }

  @override
  void dispose() {
    searchController.dispose();
    userSubscription?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // This method is rerun every time setState is called, for instance as done
    // by the _incrementCounter method above.
    //
    // The Flutter framework has been optimized to make rerunning build methods
    // fast, so that you can just rebuild anything that needs updating rather
    // than having to individually change instances of widgets.
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        centerTitle: true,
        title: const Text("Dashboard"),
      ),
      drawer: user != null
          ? Drawer(
              child: ListView(
                padding: EdgeInsets.zero,
                children: <Widget>[
                  UserAccountsDrawerHeader(
                    accountEmail: Text(user!.email),
                    accountName: Text(user!.name),
                    currentAccountPicture: CircleAvatar(
                      backgroundImage: NetworkImage(user!.imageUrl),
                    ),
                    decoration: const BoxDecoration(
                      color: Colors.deepPurple,
                    ),
                  ),
                  ListTile(
                    leading: const Icon(Icons.account_circle),
                    title: const Text('Account'),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => AccountPage()),
                      );
                    },
                  ),
                  ListTile(
                    leading: const Icon(Icons.calendar_today),
                    title: const Text('Calendar'),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const CalendarPage()),
                      );
                    },
                  ),
                  ListTile(
                    leading: const Icon(Icons.note),
                    title: const Text('Notes'),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => NotesPage()),
                      );
                    },
                  ),
                  ListTile(
                    leading: const Icon(Icons.task),
                    title: const Text('Tasks'),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => TasksPage()),
                      );
                    },
                  ),
                  ListTile(
                    leading: const Icon(Icons.center_focus_strong_rounded),
                    title: const Text('Focus'),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const FocusPage()),
                      );
                    },
                  ),
                  ListTile(
                    leading: const Icon(Icons.auto_awesome),
                    title: const Text('Achievements '),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const AchievmentsPage()),
                      );
                    },
                  ),
                  ListTile(
                    leading: const Icon(Icons.settings),
                    title: const Text('Settings'),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => SettingsPage()),
                      );
                    },
                  ),
                ],
              ),
            )
          : const Center(
              child: CircularProgressIndicator(),
            ),
      body: user != null
          ? Center(
              child: SingleChildScrollView(
                  padding: const EdgeInsets.all(10),
                  child: Column(
                    children: <Widget>[
                      Container(
                        margin: EdgeInsets.symmetric(vertical: 50),
                        padding: EdgeInsets.symmetric(horizontal: 30),
                        width: MediaQuery.of(context).size.width,
                        alignment: Alignment.center,
                        child: Text(
                          textAlign: TextAlign.center,
                          generateGreeting(user!.name),
                          style: const TextStyle(fontSize: 30),
                        ),
                      ),
                      //add a cointainer with the image next-steps.png
                      Container(
                        width: MediaQuery.of(context).size.width,
                        child: Image.asset(
                          'lib/assets/images/next-steps.png',
                          fit: BoxFit.cover,
                        ),
                      ),

                      const SizedBox(height: 10),
                      Container(
                        width: MediaQuery.of(context).size.width,
                        child: Wrap(
                          alignment: WrapAlignment.center,
                          children: <Widget>[],
                        ),
                      ),
                      // Wrap(
                      //   spacing: 10,
                      //   runSpacing: 10,
                      //   children: const <Widget>[
                      //     PlanCard(
                      //       time: '',
                      //       task: 'Remember to check your tasks',
                      //     ),
                      //     PlanCard(
                      //       time: '',
                      //       task: 'Stay focused',
                      //     ),
                      //     PlanCard(
                      //       time: '',
                      //       task: 'Save your notes',
                      //     ),

                      //     // add more plan cards here
                      //   ],
                      // ),
                    ],
                  )),
            )
          : const Center(
              child: CircularProgressIndicator(),
            ),
    );
  }
}
