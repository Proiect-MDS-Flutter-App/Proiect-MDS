import 'package:flutter/material.dart';
import 'package:reflex/assets/utils.dart';
import 'package:reflex/assets/colors/colors.dart';
import 'package:flutter/src/painting/text_style.dart';

class TimeOptions extends StatelessWidget{
  double selectedTime = 300;
  @override
  Widget build (BuildContext context){
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: selectableTimes.map((time){
          return Container(
            margin: EdgeInsets.only(left:10),
            width: 70,
            height: 50,
            decoration: BoxDecoration(
              border: Border.all(width: 3, color:green1),
              borderRadius: BorderRadius.circular(5),
            ),
              child: Center(
                child: Text(
                    (int.parse(time) ~/ 60).toString(),
                    style:TextStyle(color: green1)
                ),
              ),
              //shape: BoxShape.circle

            //   ,
            // child: Center(
            //   child: text(int.parse(time) ~/ 60).toString(),
            //   style: green1
            // )
        );
      }).toList(),
      ),
    );

  }


}