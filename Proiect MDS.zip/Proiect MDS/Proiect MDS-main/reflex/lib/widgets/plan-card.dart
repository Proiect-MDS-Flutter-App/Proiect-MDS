import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:reflex/pages/notes_page.dart';
import 'package:reflex/pages/account_page.dart';
import 'package:reflex/pages/calendar_page.dart';
import 'package:reflex/pages/tasks_page.dart';
import 'package:reflex/pages/settings_page.dart';
import 'package:reflex/pages/login_register_page.dart';
import 'package:reflex/widgets/plan-card.dart';
import 'package:firebase_core/firebase_core.dart';
import 'dart:math';
import 'dart:collection';

// class PlanCard extends StatefulWidget {
//   final String time;
//   final String task;

//   const PlanCard({
//     super.key,
//     required this.time,
//     required this.task,
//   });

//   @override
//   _PlanCardState createState() => _PlanCardState();
// }

// class _PlanCardState extends State<PlanCard> {
//   bool isChecked = false;

//   @override
//   Widget build(BuildContext context) {
//     return AnimatedContainer(
//       duration: Duration(milliseconds: 300),
//       curve: Curves.easeInOut,
//       margin: EdgeInsets.only(
//         left: isChecked ? -60 : 0,
//         right: isChecked ? 60 : 0,
//       ),
//       child: Card(
//         child: Column(
//           children: <Widget>[
//             Container(
//               padding: const EdgeInsets.all(10),
//               child: Row(
//                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                 children: [
//                   Text(widget.time),
//                   Checkbox(
//                     value: isChecked,
//                     onChanged: (bool? value) {
//                       setState(() {
//                         isChecked = value ?? true;
//                       });
//                     },
//                   ),
//                 ],
//               ),
//             ),
//             Padding(
//               padding: const EdgeInsets.all(10),
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: <Widget>[
//                   Text(
//                     widget.task,
//                     style: Theme.of(context).textTheme.headline6,
//                   ),
//                 ],
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }

class PlanCard extends StatefulWidget {
  final String time;
  final String task;

  const PlanCard({
    super.key,
    required this.time,
    required this.task,
  });

  @override
  _PlanCardState createState() => _PlanCardState();

  static void removeWhere(bool Function(dynamic plan) param0) {}
}

class _PlanCardState extends State<PlanCard> {
  void _onDismiss(DismissDirection direction) {
    setState(() {
      // Remove the plan from the list of plans
      PlanCard.removeWhere(
          (plan) => plan.time == widget.time && plan.task == widget.task);
      // You will need to access the list of plans from the parent widget
    });
  }

  @override
  Widget build(BuildContext context) {
    return Dismissible(
      key: Key(widget.time + widget.task),
      background: Container(color: Color.fromARGB(255, 187, 164, 229)),
      onDismissed: (direction) {
        _onDismiss(direction);
      },
      child: Container(
        height: 100,
        width: double.infinity,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: Colors.deepPurple,
        ),
        padding: EdgeInsets.all(10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            Text(
              widget.time,
              style: TextStyle(
                fontSize: 16,
              ),
            ),
            SizedBox(height: 10),
            Text(
              widget.task,
              style: TextStyle(
                fontSize: 20,
                color: Colors.black,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
