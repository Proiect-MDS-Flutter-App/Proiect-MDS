import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:reflex/models/task_model.dart';

class TaskService {
  final CollectionReference _taskCollectionReference =
      FirebaseFirestore.instance.collection('tasks');

  Future<void> addTask(TaskModel task) async {
    DocumentReference reference = _taskCollectionReference.doc();
    task.id = reference.id;
    await reference.set(task.toMap());
  }

  Future<TaskModel> getTask(String id) async {
    final taskDocument = await _taskCollectionReference.doc(id).get();
    return TaskModel.fromMap(taskDocument.data());
  }

  Future<List<TaskModel>> getTasksByUser(String userEmail) async {
    final tasksSnapshot = await _taskCollectionReference
        .where("user.email", isEqualTo: userEmail)
        .get();
    final List<TaskModel> tasks = [];
    for (var taskDocument in tasksSnapshot.docs) {
      tasks.add(TaskModel.fromMap(taskDocument.data()));
    }
    return tasks;
  }

  Future<void> updateTask(TaskModel task) async {
    await _taskCollectionReference.doc(task.id).update(task.toMap());
  }

  Future<void> deleteTask(String id) async {
    await _taskCollectionReference.doc(id).delete();
  }
}
