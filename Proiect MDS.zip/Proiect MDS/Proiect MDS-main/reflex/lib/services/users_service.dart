import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:reflex/models/user_model.dart';
import 'package:reflex/services/auth_service.dart';

class UserService {
  final CollectionReference _usersCollectionReference =
      FirebaseFirestore.instance.collection('users');

  Future<UserModel> addUser(UserModel user) async {
    final userDocument = await _usersCollectionReference.add(user.toMap());
    return user.copyWith(id: userDocument.id);
  }

  Future<UserModel> getUser(String? email) async {
    final querySnapshot =
        await _usersCollectionReference.where('email', isEqualTo: email).get();
    if (querySnapshot.docs.isNotEmpty) {
      final user = UserModel.fromMap(querySnapshot.docs.first.data());
      return user;
    } else {
      throw Exception('User not found');
    }
  }

  Future<UserModel> getCurrentUser() async {
    final user = await AuthService().getCurrentUser();
    return getUser(user!.email);
  }

  Future<void> updateUser(UserModel user, String? email) async {
    final querySnapshot =
        await _usersCollectionReference.where('email', isEqualTo: email).get();
    if (querySnapshot.docs.isNotEmpty) {
      await _usersCollectionReference.doc(querySnapshot.docs.first.id).update(
            user.toMap(),
          );
    } else {
      throw Exception('User not found');
    }
  }

  Future<void> deleteUser(String email) async {
    await _usersCollectionReference.doc(email).delete();
  }

  Stream<UserModel> streamUser(String? email) {
    return _usersCollectionReference
        .where('email', isEqualTo: email)
        .snapshots()
        .map((event) => UserModel.fromMap(event.docs.first.data()));
  }
}
