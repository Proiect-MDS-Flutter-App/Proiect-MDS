import 'dart:io';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';

class ImageService {
  static Future<String> uploadImage(File image) async {
    final ref = FirebaseStorage.instance.ref().child('user_images').child(
          DateTime.now().toString() + '.jpg',
        );
    await ref.putFile(image);
    final url = await ref.getDownloadURL();
    return url;
  }
}
