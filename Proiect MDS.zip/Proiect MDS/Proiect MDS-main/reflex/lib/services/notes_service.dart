import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:reflex/models/note_model.dart';

class NotesService {
  final CollectionReference _notesCollectionReference =
      FirebaseFirestore.instance.collection('notes');

  Future<void> addNote(NoteModel note) async {
    DocumentReference reference = _notesCollectionReference.doc();
    note.id = reference.id;
    await reference.set(note.toMap());
  }

  Future<NoteModel> getNote(String id) async {
    final noteDocument = await _notesCollectionReference.doc(id).get();
    return NoteModel.fromMap(noteDocument.data());
  }

  Future<List<NoteModel>> getNotesByUser(String userEmail) async {
    final notesSnapshot = await _notesCollectionReference
        .where("user.email", isEqualTo: userEmail)
        .get();
    final List<NoteModel> notes = [];
    for (var noteDocument in notesSnapshot.docs) {
      notes.add(NoteModel.fromMap(noteDocument.data()));
    }
    return notes;
  }

  Future<void> updateNote(NoteModel note) async {
    await _notesCollectionReference.doc(note.id).update(note.toMap());
  }

  Future<void> deleteNote(String id) async {
    await _notesCollectionReference.doc(id).delete();
  }
}
