import 'package:flutter/material.dart';
List selectableTimes=[
  "300",//5
  "600",//10
  "900",//15
  "1200",//20
  "1500",//25
  "1800",//30,
  "2700",//45
  "3600",//60
  "4500",//75
  "5400",//90





];