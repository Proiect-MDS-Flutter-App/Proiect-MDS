import 'package:flutter/material.dart';

// all the colors used in the app.

Color green1 = const Color(0xFF673AB7);
Color green2 = const Color(0xFF38A3A5);
Color green3 = const Color(0xFF57CC99);
Color green4 = const Color(0xFFb19cd8);